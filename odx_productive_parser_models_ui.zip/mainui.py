import sys
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout,
    QPushButton, QTreeWidget, QTreeWidgetItem
)
from PySide6.QtCore import Qt

from parser import ODXParser
from models import OdxParam, OdxDatabase


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ODX Explorer")

        self.parser = ODXParser()
        self.database: OdxDatabase | None = None

        root = QWidget()
        layout = QVBoxLayout(root)

        btn = QPushButton("Load ODX (XML)")
        btn.clicked.connect(self.load_files)
        layout.addWidget(btn)

        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Name", "Semantic", "Value"])
        layout.addWidget(self.tree)

        self.setCentralWidget(root)

    def load_files(self):
        # Minimal demo load; replace with QFileDialog in your app
        with open("sample.odx", "rb") as f:
            _, container = self.parser.parse_odx_bytes("sample.odx", f.read())

        self.database = OdxDatabase(
            ecuVariants=container.ecuVariants,
            baseVariants=[]
        )
        self.populate_tree()

    def populate_tree(self):
        self.tree.clear()
        if not self.database:
            return

        for v in self.database.ecuVariants:
            v_item = QTreeWidgetItem([v.shortName, v.layerType, ""])
            self.tree.addTopLevelItem(v_item)

            for s in v.services:
                s_item = QTreeWidgetItem([s.shortName, s.semantic, ""])
                v_item.addChild(s_item)

                if s.request:
                    r_item = QTreeWidgetItem([s.request.shortName, "REQUEST", ""])
                    s_item.addChild(r_item)
                    for p in s.request.params:
                        self._add_param(r_item, p)

                for pr in s.posResponses:
                    pr_item = QTreeWidgetItem([pr.shortName, "POS_RESPONSE", ""])
                    s_item.addChild(pr_item)
                    for p in pr.params:
                        self._add_param(pr_item, p)

        self.tree.expandAll()

    def _add_param(self, parent, p: OdxParam):
        item = QTreeWidgetItem([
            p.shortName,
            p.semantic,
            p.displayHex or p.value or ""
        ])
        item.setFlags(
            item.flags()
            | Qt.ItemFlag.ItemIsUserCheckable
            | Qt.ItemFlag.ItemIsSelectable
        )
        item.setCheckState(0, Qt.CheckState.Unchecked)
        item.setData(0, Qt.ItemDataRole.UserRole, p)
        parent.addChild(item)


def main():
    app = QApplication(sys.argv)
    w = MainWindow()
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
