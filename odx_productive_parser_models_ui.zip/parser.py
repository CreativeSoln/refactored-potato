from __future__ import annotations
from typing import Tuple
import xml.etree.ElementTree as ET

from models import (
    OdxContainer, OdxLayer, OdxService, OdxMessage, OdxParam
)

class ODXParser:
    """Productive parser skeleton.
    This parses enough structure to drive the UI:
    ECU-VARIANT -> SERVICE -> REQUEST / POS-RESPONSE -> PARAM (recursive).
    """

    def parse_odx_bytes(self, filename: str, content: bytes) -> Tuple[str, OdxContainer]:
        root = ET.fromstring(content)
        container = OdxContainer()

        for ev in root.iter("ECU-VARIANT"):
            layer = OdxLayer(
                layerType="ECU-VARIANT",
                id=ev.attrib.get("ID", ""),
                shortName=self._text(ev, "SHORT-NAME"),
            )

            for svc_el in ev.iter("DIAG-SERVICE"):
                svc = self._parse_service(svc_el, layer.shortName)
                layer.services.append(svc)

            container.ecuVariants.append(layer)

        return filename, container

    # ---------------- helpers ----------------

    def _parse_service(self, svc_el, layer_name: str) -> OdxService:
        svc = OdxService(
            id=svc_el.attrib.get("ID", ""),
            shortName=self._text(svc_el, "SHORT-NAME"),
            semantic=svc_el.attrib.get("SEMANTIC", ""),
        )

        req_el = svc_el.find("REQUEST")
        if req_el is not None:
            svc.request = self._parse_message(req_el, "REQUEST", layer_name, svc.shortName)

        for pr in svc_el.findall("POS-RESPONSE"):
            svc.posResponses.append(
                self._parse_message(pr, "POS_RESPONSE", layer_name, svc.shortName)
            )

        return svc

    def _parse_message(self, msg_el, kind: str, layer: str, svc: str) -> OdxMessage:
        msg = OdxMessage(
            id=msg_el.attrib.get("ID", ""),
            shortName=self._text(msg_el, "SHORT-NAME") or kind,
        )

        for p_el in msg_el.iter("PARAM"):
            msg.params.append(
                self._parse_param(p_el, kind, layer, svc)
            )

        return msg

    def _parse_param(self, p_el, parent_type: str, layer: str, svc: str) -> OdxParam:
        p = OdxParam(
            id=f"{layer}:{svc}:{parent_type}:{self._text(p_el,'SHORT-NAME')}",
            shortName=self._text(p_el, "SHORT-NAME"),
            semantic=p_el.attrib.get("SEMANTIC", ""),
            parentType=parent_type,
            layerName=layer,
            serviceShortName=svc,
        )

        p.codedConstValue = self._text(p_el, "CODED-VALUE")
        p.physConstValue = self._text(p_el, "PHYS-VALUE")

        if p.codedConstValue:
            p.rawHex = p.codedConstValue
            p.displayHex = f"0x{p.codedConstValue}"
            p.value = p.codedConstValue

        return p

    def _text(self, el, tag: str) -> str:
        c = el.find(tag)
        return (c.text or "").strip() if c is not None else ""
