from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

@dataclass
class OdxParam:
    id: str
    shortName: str
    longName: str = ""
    description: str = ""
    semantic: str = ""

    bytePosition: str = ""
    bitPosition: str = ""
    bitLength: str = ""

    baseDataType: str = ""
    physicalBaseType: str = ""

    # Explicit value model (no UI guesswork)
    value: Optional[str] = None
    rawHex: Optional[str] = None
    displayHex: Optional[str] = None
    requestDidHex: Optional[str] = None

    codedConstValue: str = ""
    physConstValue: str = ""

    parentType: str = ""
    parentName: str = ""
    layerName: str = ""
    serviceShortName: str = ""

    children: List["OdxParam"] = field(default_factory=list)
    attrs: Dict[str, Any] = field(default_factory=dict)


@dataclass
class OdxMessage:
    id: str
    shortName: str
    longName: str = ""
    params: List[OdxParam] = field(default_factory=list)


@dataclass
class OdxService:
    id: str
    shortName: str
    semantic: str = ""
    sid: Optional[int] = None
    request: Optional[OdxMessage] = None
    posResponses: List[OdxMessage] = field(default_factory=list)
    negResponses: List[OdxMessage] = field(default_factory=list)


@dataclass
class OdxLayer:
    layerType: str
    id: str
    shortName: str
    services: List[OdxService] = field(default_factory=list)


@dataclass
class OdxContainer:
    ecuVariants: List[OdxLayer] = field(default_factory=list)
    baseVariants: List[OdxLayer] = field(default_factory=list)


@dataclass
class OdxDatabase:
    ecuVariants: List[OdxLayer] = field(default_factory=list)
    baseVariants: List[OdxLayer] = field(default_factory=list)
