from __future__ import annotations
import os
import re
import sys
import json
import zipfile
import traceback
from typing import Optional, List, Set, Dict, Any
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QGuiApplication
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget,
    QVBoxLayout, QHBoxLayout, QPushButton,
    QLineEdit, QLabel, QSplitter, QTreeWidget,
    QTreeWidgetItem, QScrollArea, QFormLayout,
    QStatusBar, QFileDialog, QMessageBox, QComboBox,
)

from parser import ODXParser
from models import OdxService, OdxParam, OdxDatabase, OdxLayer

def _is_odx(name: str) -> bool:
    n = name.lower()
    return bool(re.search(r"\.odx(\-[a-z]+)?$", n)) or n.endswith(".xml")

class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("ODX Diagnostic Explorer")
        self.resize(1680, 950)
        self.parser = ODXParser()
        self.database: Optional[OdxDatabase] = None
        self.selectedParams: List[OdxParam] = []
        self._filter_text: str = ""
        self._filter_variant: str = ""
        self._filter_variant_type: str = "EV"
        self._filter_semantic: str = ""
        self._filter_sid_int: Optional[int] = None
        self._filter_timer = QTimer(self); self._filter_timer.setSingleShot(True); self._filter_timer.setInterval(200)
        self._filter_timer.timeout.connect(lambda: self.apply_all_filters())
        self._suppress_item_changed: bool = False
        self.build_ui(); self.apply_theme_light()

    def build_ui(self) -> None:
        root = QWidget(); layout = QVBoxLayout(root)
        tb = QHBoxLayout()
        self.btn_open = QPushButton("Open PDX/ODX"); self.btn_open.clicked.connect(self.open_files); tb.addWidget(self.btn_open)
        self.cmb_variant = QComboBox(); self.cmb_variant.setMinimumWidth(240); self.cmb_variant.addItem("All Variants", userData=""); self.cmb_variant.currentIndexChanged.connect(self.on_variant_changed)
        tb.addWidget(QLabel("Variant:")); tb.addWidget(self.cmb_variant)
        self.cmb_semantic = QComboBox(); self.cmb_semantic.setMinimumWidth(180); self.cmb_semantic.addItem("All semantics", userData=""); self.cmb_semantic.currentIndexChanged.connect(self.apply_all_filters)
        tb.addWidget(QLabel("Service Semantic:")); tb.addWidget(self.cmb_semantic)
        self.cmb_sid = QComboBox(); self.cmb_sid.setMinimumWidth(180); self.cmb_sid.addItem("All SIDs", userData=None); self.cmb_sid.currentIndexChanged.connect(self.apply_all_filters)
        tb.addWidget(QLabel("SID:")); tb.addWidget(self.cmb_sid)
        self.search = QLineEdit(); self.search.setPlaceholderText("Search Variant, Service, Message, Parameter..."); self.search.textChanged.connect(lambda: self._filter_timer.start()); tb.addWidget(self.search, 1)
        self.lbl_layers = QLabel("0 layers"); tb.addWidget(self.lbl_layers)
        self.lbl_selected = QLabel("0/0 selected"); tb.addWidget(self.lbl_selected)
        self.btn_select_all = QPushButton("Select All Visible"); self.btn_select_all.clicked.connect(self.select_all_visible_params); tb.addWidget(self.btn_select_all)
        self.btn_clear_sel = QPushButton("Clear Selection"); self.btn_clear_sel.clicked.connect(self.clear_selection); tb.addWidget(self.btn_clear_sel)
        self.btn_copy_did = QPushButton("Copy DID"); self.btn_copy_did.clicked.connect(self.copy_current_did); tb.addWidget(self.btn_copy_did)
        self.btn_json = QPushButton("Export JSON"); self.btn_json.clicked.connect(self.export_json); tb.addWidget(self.btn_json)
        self.btn_excel = QPushButton("Export Excel"); self.btn_excel.clicked.connect(self.export_excel); tb.addWidget(self.btn_excel)
        self.btn_reset = QPushButton("Reset"); self.btn_reset.clicked.connect(self.reset_all); tb.addWidget(self.btn_reset)
        layout.addLayout(tb)
        split = QSplitter(Qt.Orientation.Horizontal); layout.addWidget(split, 1)
        self.tree = QTreeWidget(); self.tree.setHeaderLabels(["Variants & Services", "Type / Semantic", "Info"])
        self.tree.setUniformRowHeights(True); self.tree.itemSelectionChanged.connect(self.tree_selected); self.tree.itemChanged.connect(self.tree_item_changed); self.tree.setExpandsOnDoubleClick(True)
        split.addWidget(self.tree)
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        self.details_host = QWidget(); self.details = QFormLayout(self.details_host); scroll.setWidget(self.details_host)
        split.addWidget(scroll); split.setStretchFactor(0, 3); split.setStretchFactor(1, 2)
        self.sb = QStatusBar(); self.setStatusBar(self.sb); self.setCentralWidget(root)

    def apply_theme_light(self) -> None:
        self.setStyleSheet("")

    # File Ops
    def open_files(self) -> None:
        files, _ = QFileDialog.getOpenFileNames(self, "Open PDX/ODX/XML", "", "ODX Files (*.odx *.xml *.pdx *.zip)")
        if not files: return
        try:
            self.load_files(files)
        except Exception as e:
            traceback.print_exc(); QMessageBox.critical(self, "Parse error", str(e))

    def _parse_any(self, name: str, raw: bytes):
        return self.parser.parse_odx_bytes(name, raw)

    def _merge_containers(self, containers: List[Any]) -> OdxDatabase:
        return self.parser.merge_containers([c[1] if isinstance(c, tuple) else c for c in containers])

    def load_files(self, files: List[str]) -> None:
        self.reset_all(clear_status=False)
        containers: List[Any] = []
        for p in files:
            try:
                lower = p.lower()
                if lower.endswith('.pdx') or lower.endswith('.zip'):
                    with zipfile.ZipFile(p, 'r') as zf:
                        for name in zf.namelist():
                            if name.endswith('/'):
                                continue
                            if not _is_odx(name):
                                continue
                            raw = zf.read(name)
                            containers.append(self._parse_any(os.path.basename(name), raw))
                else:
                    with open(p, 'rb') as f:
                        raw = f.read()
                    containers.append(self._parse_any(os.path.basename(p), raw))
            except Exception:
                traceback.print_exc(); continue
        if not containers:
            self.sb.showMessage("No valid ODX parsed"); return
        try:
            self.database = self._merge_containers(containers)
        except Exception as ex:
            traceback.print_exc(); QMessageBox.critical(self, "Merge error", f"Failed to merge containers: {ex}"); return
        self.sb.showMessage("Load complete")

    # Actions
    def export_json(self) -> None:
        if not self.database:
            self.sb.showMessage("No database loaded"); return
        try:
            path, _ = QFileDialog.getSaveFileName(self, "Save JSON", "export.json", "JSON (*.json)")
            if not path: return
            data = {
                "ecuVariants": [getattr(ev, "shortName", "") for ev in getattr(self.database, "ecuVariants", []) or []],
                "baseVariants": [getattr(bv, "shortName", "") for bv in getattr(self.database, "baseVariants", []) or []],
                "paramsCount": len(getattr(self.database, "allParams", []) or [])
            }
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            self.sb.showMessage(f"Exported JSON to {path}")
        except Exception as ex:
            traceback.print_exc(); QMessageBox.critical(self, "Export error", str(ex))

    def export_excel(self) -> None:
        QMessageBox.information(self, "Export Excel", "Excel export not implemented yet.")

    def reset_all(self, clear_status: bool = True) -> None:
        self.tree.clear(); self.selectedParams.clear()
        self._filter_text = ""; self._filter_variant = ""; self._filter_semantic = ""; self._filter_sid_int = None
        if clear_status:
            self.sb.showMessage("Reset complete")

    # Placeholder methods used by signals in UI
    def on_variant_changed(self): pass
    def apply_all_filters(self, initial_build: bool = False): pass
    def select_all_visible_params(self): pass
    def clear_selection(self): pass
    def tree_selected(self): pass
    def tree_item_changed(self, item, col): pass
    def _check_ancestors(self, item): pass
    def _set_descendant_checkstate(self, item, state): pass
    def _refresh_ancestor_state(self, item): pass
    def _clear_form(self, form): pass
    def _add_detail(self, key, value): pass
    def show_param_details(self, p): pass
    def copy_current_did(self): pass

# Main
def main() -> None:
    app = QApplication(sys.argv)
    w = MainWindow(); w.show(); sys.exit(app.exec())

if __name__ == "__main__":
    main()
