from __future__ import annotations
import os
import re
import sys
import json
import zipfile
import traceback
from typing import Optional, List, Set, Dict, Any

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QGuiApplication
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget,
    QVBoxLayout, QHBoxLayout, QPushButton,
    QLineEdit, QLabel, QSplitter, QTreeWidget,
    QTreeWidgetItem, QScrollArea, QFormLayout,
    QStatusBar, QFileDialog, QMessageBox, QComboBox,
)

from parser import ODXParser
from models import OdxService, OdxParam, OdxDatabase, OdxLayer


def _is_odx(name: str) -> bool:
    n = name.lower()
    return bool(re.search(r"\.odx(\-[a-z]+)?$", n)) or n.endswith(".xml")

class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("ODX Diagnostic Explorer")
        self.resize(1680, 950)
        self.parser = ODXParser()
        self.database: Optional[OdxDatabase] = None
        self.selectedParams: List[OdxParam] = []
        self._filter_text: str = ""
        self._filter_variant: str = ""
        self._filter_variant_type: str = "EV"
        self._filter_semantic: str = ""
        self._filter_sid_int: Optional[int] = None
        self._filter_timer = QTimer(self); self._filter_timer.setSingleShot(True); self._filter_timer.setInterval(200)
        self._filter_timer.timeout.connect(lambda: self.apply_all_filters())
        self._suppress_item_changed: bool = False
        self.build_ui(); self.apply_theme_light()

    def build_ui(self) -> None:
        root = QWidget(); layout = QVBoxLayout(root)
        tb = QHBoxLayout()
        self.btn_open = QPushButton("Open PDX/ODX"); self.btn_open.clicked.connect(self.open_files); tb.addWidget(self.btn_open)
        self.cmb_variant = QComboBox(); self.cmb_variant.setMinimumWidth(240); self.cmb_variant.addItem("All Variants", userData=""); self.cmb_variant.currentIndexChanged.connect(self.on_variant_changed)
        tb.addWidget(QLabel("Variant:")); tb.addWidget(self.cmb_variant)
        self.cmb_semantic = QComboBox(); self.cmb_semantic.setMinimumWidth(180); self.cmb_semantic.addItem("All semantics", userData=""); self.cmb_semantic.currentIndexChanged.connect(self.apply_all_filters)
        tb.addWidget(QLabel("Service Semantic:")); tb.addWidget(self.cmb_semantic)
        self.cmb_sid = QComboBox(); self.cmb_sid.setMinimumWidth(180); self.cmb_sid.addItem("All SIDs", userData=None); self.cmb_sid.currentIndexChanged.connect(self.apply_all_filters)
        tb.addWidget(QLabel("SID:")); tb.addWidget(self.cmb_sid)
        self.search = QLineEdit(); self.search.setPlaceholderText("Search Variant, Service, Message, Parameter..."); self.search.textChanged.connect(lambda: self._filter_timer.start()); tb.addWidget(self.search, 1)
        self.lbl_layers = QLabel("0 layers"); tb.addWidget(self.lbl_layers)
        self.lbl_selected = QLabel("0/0 selected"); tb.addWidget(self.lbl_selected)
        self.btn_select_all = QPushButton("Select All Visible"); self.btn_select_all.clicked.connect(self.select_all_visible_params); tb.addWidget(self.btn_select_all)
        self.btn_clear_sel = QPushButton("Clear Selection"); self.btn_clear_sel.clicked.connect(self.clear_selection); tb.addWidget(self.btn_clear_sel)
        self.btn_copy_did = QPushButton("Copy DID"); self.btn_copy_did.setToolTip("Copies DID only if provided by the model."); self.btn_copy_did.clicked.connect(self.copy_current_did); tb.addWidget(self.btn_copy_did)
        self.btn_json = QPushButton("Export JSON"); self.btn_json.clicked.connect(self.export_json); tb.addWidget(self.btn_json)
        self.btn_excel = QPushButton("Export Excel"); self.btn_excel.clicked.connect(self.export_excel); tb.addWidget(self.btn_excel)
        self.btn_reset = QPushButton("Reset"); self.btn_reset.clicked.connect(self.reset_all); tb.addWidget(self.btn_reset)
        layout.addLayout(tb)
        split = QSplitter(Qt.Orientation.Horizontal); layout.addWidget(split, 1)
        self.tree = QTreeWidget(); self.tree.setHeaderLabels(["Variants & Services", "Type / Semantic", "Info"])
        self.tree.setUniformRowHeights(True); self.tree.itemSelectionChanged.connect(self.tree_selected); self.tree.itemChanged.connect(self.tree_item_changed); self.tree.setExpandsOnDoubleClick(True)
        split.addWidget(self.tree)
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        self.details_host = QWidget(); self.details_host.setObjectName("DetailsPane")
        self.details = QFormLayout(self.details_host); scroll.setWidget(self.details_host)
        split.addWidget(scroll); split.setStretchFactor(0, 3); split.setStretchFactor(1, 2)
        self.sb = QStatusBar(); self.setStatusBar(self.sb); self.setCentralWidget(root)

    def apply_theme_light(self) -> None:
        self.setStyleSheet("""
        QMainWindow { background: #fafafa; color:#222; }
        QTreeWidget, QScrollArea { background:#ffffff; color:#222; border:1px solid #d9d9d9; }
        QHeaderView::section { background: #fefef0; padding:4px; border: 0px; color:#444; }
        QLineEdit, QComboBox { background:#ffffff; border:1px solid #cfcfcf; padding: 6px; color:#222; }
        QTreeWidget::item { padding:4px 6px; }
        QTreeWidget::item:selected { background: #dbeafe; color:#111827; }
        QPushButton { background: #f5f5f5; padding:8px; border:1px solid #dedede; color:#222; border-radius: 6px; }
        QPushButton:hover { background:#ededed; }
        QStatusBar { background:#fefefe; color:#222; }
        """)

    # ----------------------------- File Ops -----------------------------
    def open_files(self) -> None:
        files, _ = QFileDialog.getOpenFileNames(self, "Open PDX/ODX/XML", "", "ODX Files (*.odx *.xml *.pdx *.zip)")
        if not files: return
        try:
            self.load_files(files)
        except Exception as e:
            traceback.print_exc(); QMessageBox.critical(self, "Parse error", str(e))

    def _parse_any(self, name: str, raw: bytes):
        return self.parser.parse_odx_bytes(name, raw)

    def _merge_containers(self, containers: List[Any]) -> OdxDatabase:
        return self.parser.merge_containers([c[1] if isinstance(c, tuple) else c for c in containers])

    def load_files(self, files: List[str]) -> None:
        self.reset_all(clear_status=False)
        containers: List[Any] = []
        for p in files:
            try:
                lower = p.lower()
                if lower.endswith('.pdx') or lower.endswith('.zip'):
                    with zipfile.ZipFile(p, 'r') as zf:
                        for name in zf.namelist():
                            if name.endswith('/'):
                                continue
                            if not _is_odx(name):
                                continue
                            raw = zf.read(name)
                            containers.append(self._parse_any(os.path.basename(name), raw))
                else:
                    with open(p, 'rb') as f:
                        raw = f.read()
                    containers.append(self._parse_any(os.path.basename(p), raw))
            except Exception:
                traceback.print_exc(); continue
        if not containers:
            self.sb.showMessage("No valid ODX parsed"); return
        try:
            self.database = self._merge_containers(containers)
        except Exception as ex:
            traceback.print_exc(); QMessageBox.critical(self, "Merge error", f"Failed to merge containers: {ex}"); return
        try:
            self.populate_filters(self.database)
            self.populate_tree(self.database)
        except Exception as ex:
            traceback.print_exc(); QMessageBox.critical(self, "Tree build error", str(ex)); return
        total_layers = (
            len(getattr(self.database, 'ecuVariants', []) or []) +
            len(getattr(self.database, 'baseVariants', []) or [])
        )
        self.lbl_layers.setText(f"{total_layers} layers")
        self.sb.showMessage(f"Load complete, {total_layers} layers")
        self.apply_all_filters(initial_build=True)

    # ----------------------------- Filters UI -----------------------------
    def on_variant_changed(self) -> None:
        self._repopulate_sid_for_variant(); self.apply_all_filters()

    def populate_filters(self, db: OdxDatabase) -> None:
        evs = getattr(db, 'ecuVariants', []) or []
        bvs = getattr(db, 'baseVariants', []) or []
        self._filter_variant_type = 'EV' if len(evs) > 0 else ('BV' if len(bvs) > 0 else 'EV')
        self.cmb_variant.blockSignals(True); self.cmb_variant.clear()
        if self._filter_variant_type == 'EV':
            self.cmb_variant.addItem('All ECU Variants', userData='')
            for ev in evs:
                self.cmb_variant.addItem(ev.shortName or '(unnamed ECU Variant)', userData=ev.shortName or '')
        else:
            self.cmb_variant.addItem('All Base Variants', userData='')
            for bv in bvs:
                self.cmb_variant.addItem(bv.shortName or '(unnamed Base Variant)', userData=bv.shortName or '')
        self.cmb_variant.blockSignals(False)
        semantics: Set[str] = set()
        for group in (evs + bvs):
            for svc in (getattr(group, 'services', []) or []):
                if svc.semantic:
                    semantics.add(svc.semantic)
        sem_list = sorted(semantics, key=lambda s: s.lower())
        self.cmb_semantic.blockSignals(True); self.cmb_semantic.clear(); self.cmb_semantic.addItem('All semantics', userData='')
        for s in sem_list:
            self.cmb_semantic.addItem(s, userData=s)
        self.cmb_semantic.blockSignals(False)
        self._repopulate_sid_for_variant()
        self._filter_variant = ''
        self._filter_semantic = ''
        self._filter_sid_int = None
        self._filter_text = (self.search.text() or '').strip().lower()

    def _repopulate_sid_for_variant(self) -> None:
        if not self.database:
            return
        target_sn = (self.cmb_variant.currentData() or '')
        if self._filter_variant_type == 'EV':
            layers = [ev for ev in (getattr(self.database, 'ecuVariants', []) or []) if not target_sn or (ev.shortName or '') == target_sn]
        else:
            layers = [bv for bv in (getattr(self.database, 'baseVariants', []) or []) if not target_sn or (bv.shortName or '') == target_sn]
        sids: Set[int] = set()
        for layer in layers:
            for svc in getattr(layer, 'services', []) or []:
                if isinstance(getattr(svc, 'sid', None), int):
                    sids.add(svc.sid)
        old_sid = self.cmb_sid.currentData()
        self.cmb_sid.blockSignals(True); self.cmb_sid.clear(); self.cmb_sid.addItem('All SIDs', userData=None)
        for sid in sorted(sids):
            self.cmb_sid.addItem(f"0x{sid:X} ({sid})", userData=sid)
        self.cmb_sid.blockSignals(False)
        if old_sid is not None:
            for i in range(self.cmb_sid.count()):
                if self.cmb_sid.itemData(i) == old_sid:
                    self.cmb_sid.setCurrentIndex(i); break
        else:
            self.cmb_sid.setCurrentIndex(0)

    # ----------------------------- Tree Build -----------------------------
    def populate_tree(self, db: OdxDatabase) -> None:
        self.tree.clear()
        ev_root = QTreeWidgetItem(["ECU Variants", "", ""])
        bv_root = QTreeWidgetItem(["Base Variants", "", ""])
        self.tree.addTopLevelItem(ev_root); self.tree.addTopLevelItem(bv_root)
        for ev in getattr(db, 'ecuVariants', []) or []:
            ev_item = QTreeWidgetItem([ev.shortName or '(unnamed ECU Variant)', '', ''])
            ev_root.addChild(ev_item)
            for svc in getattr(ev, 'services', []) or []:
                svc_item = QTreeWidgetItem([svc.shortName or '(service)', getattr(svc, 'semantic', '') or '', getattr(svc, 'infoText', '') or ''])
                svc_item.setData(0, Qt.ItemDataRole.UserRole, svc)
                ev_item.addChild(svc_item)
                for msg in ([svc.request] + list(svc.posResponses or []) + list(svc.negResponses or [])):
                    if not msg: continue
                    msg_item = QTreeWidgetItem([getattr(msg, 'shortName', '') or '(message)', '', ''])
                    svc_item.addChild(msg_item)
                    for p in getattr(msg, 'params', []) or []:
                        p_item = QTreeWidgetItem([getattr(p, 'shortName', '') or '(param)', '', ''])
                        p_item.setData(0, Qt.ItemDataRole.UserRole, p)
                        if getattr(p, 'isSelectableFor22', None) is False:
                            font = p_item.font(0); font.setItalic(True)
                            p_item.setFont(0, font); p_item.setToolTip(0, 'Domain marked non-selectable for 0x22')
                        else:
                            p_item.setFlags(p_item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                            p_item.setCheckState(0, Qt.CheckState.Unchecked)
                        msg_item.addChild(p_item)
        for bv in getattr(db, 'baseVariants', []) or []:
            bv_item = QTreeWidgetItem([bv.shortName or '(unnamed Base Variant)', '', ''])
            bv_root.addChild(bv_item)
            for svc in getattr(bv, 'services', []) or []:
                svc_item = QTreeWidgetItem([svc.shortName or '(service)', getattr(svc, 'semantic', '') or '', getattr(svc, 'infoText', '') or ''])
                svc_item.setData(0, Qt.ItemDataRole.UserRole, svc)
                bv_item.addChild(svc_item)
                for msg in ([svc.request] + list(svc.posResponses or []) + list(svc.negResponses or [])):
                    if not msg: continue
                    msg_item = QTreeWidgetItem([getattr(msg, 'shortName', '') or '(message)', '', ''])
                    svc_item.addChild(msg_item)
                    for p in getattr(msg, 'params', []) or []:
                        p_item = QTreeWidgetItem([getattr(p, 'shortName', '') or '(param)', '', ''])
                        p_item.setData(0, Qt.ItemDataRole.UserRole, p)
                        if getattr(p, 'isSelectableFor22', None) is False:
                            font = p_item.font(0); font.setItalic(True)
                            p_item.setFont(0, font); p_item.setToolTip(0, 'Domain marked non-selectable for 0x22')
                        else:
                            p_item.setFlags(p_item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                            p_item.setCheckState(0, Qt.CheckState.Unchecked)
                        msg_item.addChild(p_item)
        self.tree.expandItem(ev_root); self.tree.expandItem(bv_root)

    # ----------------------------- Filtering -----------------------------
    def apply_all_filters(self, initial_build: bool = False) -> None:
        self.tree.setUpdatesEnabled(False)
        try:
            self._filter_text = (self.search.text() or '').strip().lower()
            self._filter_variant = self.cmb_variant.currentData() or ''
            self._filter_semantic = self.cmb_semantic.currentData() or ''
            self._filter_sid_int = self.cmb_sid.currentData()
            for i in range(self.tree.topLevelItemCount()):
                top = self.tree.topLevelItem(i)
                group_name = (top.text(0) or '')
                for j in range(top.childCount()):
                    layer = top.child(j)
                    layer_name = (layer.text(0) or '')
                    layer_is_ev = (group_name == 'ECU Variants')
                    layer_is_bv = (group_name == 'Base Variants')
                    hide_layer = False
                    if self._filter_variant:
                        if self._filter_variant_type == 'EV' and layer_is_ev:
                            hide_layer = (layer_name != self._filter_variant)
                        elif self._filter_variant_type == 'BV' and layer_is_bv:
                            hide_layer = (layer_name != self._filter_variant)
                    layer.setHidden(hide_layer)
                    if hide_layer:
                        continue
                    show_layer = False
                    for k in range(layer.childCount()):
                        svc_item = layer.child(k)
                        svc_name = (svc_item.text(0) or '').lower()
                        svc_payload = svc_item.data(0, Qt.ItemDataRole.UserRole)
                        svc_semantic = getattr(svc_payload, 'semantic', '') if isinstance(svc_payload, OdxService) else ''
                        sid_val = getattr(svc_payload, 'sid', None) if isinstance(svc_payload, OdxService) else None
                        svc_match_text = (self._filter_text in svc_name) if self._filter_text else True
                        svc_match_sem = ((not self._filter_semantic) or (svc_semantic == self._filter_semantic))
                        svc_match_sid = ((self._filter_sid_int is None) or (sid_val == self._filter_sid_int))
                        any_child_visible = False
                        for m in range(svc_item.childCount()):
                            msg_item = svc_item.child(m)
                            msg_name = (msg_item.text(0) or '').lower()
                            msg_match_text = (self._filter_text in msg_name) if self._filter_text else True
                            any_param_visible = False
                            for pidx in range(msg_item.childCount()):
                                p_item = msg_item.child(pidx)
                                pname = (p_item.text(0) or '').lower()
                                p_match_text = (self._filter_text in pname) if self._filter_text else True
                                visible = (p_match_text and svc_match_sem and svc_match_sid)
                                p_item.setHidden(not visible)
                                any_param_visible = any_param_visible or visible
                            msg_visible = (svc_match_sem and svc_match_sid and (msg_match_text or any_param_visible))
                            msg_item.setHidden(not msg_visible)
                            any_child_visible = any_child_visible or msg_visible
                        svc_visible = (svc_match_sem and svc_match_sid and (svc_match_text or any_child_visible))
                        svc_item.setHidden(not svc_visible)
                        show_layer = show_layer or svc_visible
                    layer.setHidden(not show_layer)
        finally:
            self.tree.setUpdatesEnabled(True)

    # ----------------------------- Selection helpers -----------------------------
    def select_all_visible_params(self) -> None:
        for i in range(self.tree.topLevelItemCount()):
            top = self.tree.topLevelItem(i)
            for j in range(top.childCount()):
                layer = top.child(j)
                if layer.isHidden(): continue
                for k in range(layer.childCount()):
                    svc_item = layer.child(k)
                    if svc_item.isHidden(): continue
                    for m in range(svc_item.childCount()):
                        msg_item = svc_item.child(m)
                        if msg_item.isHidden(): continue
                        for pidx in range(msg_item.childCount()):
                            p_item = msg_item.child(pidx)
                            if p_item.isHidden(): continue
                            if (p_item.flags() & Qt.ItemFlag.ItemIsUserCheckable) and p_item.checkState(0) != Qt.CheckState.Checked:
                                p_item.setCheckState(0, Qt.CheckState.Checked)
        self.update_selection_label()

    def clear_selection(self) -> None:
        for i in range(self.tree.topLevelItemCount()):
            top = self.tree.topLevelItem(i)
            for j in range(top.childCount()):
                layer = top.child(j)
                for k in range(layer.childCount()):
                    svc_item = layer.child(k)
                    for m in range(svc_item.childCount()):
                        msg_item = svc_item.child(m)
                        for pidx in range(msg_item.childCount()):
                            p_item = msg_item.child(pidx)
                            if (p_item.flags() & Qt.ItemFlag.ItemIsUserCheckable) and p_item.checkState(0) == Qt.CheckState.Checked:
                                p_item.setCheckState(0, Qt.CheckState.Unchecked)
        self.selectedParams.clear(); self.update_selection_label()

    def update_selection_label(self) -> None:
        total = 0; selected = 0
        for i in range(self.tree.topLevelItemCount()):
            top = self.tree.topLevelItem(i)
            for j in range(top.childCount()):
                layer = top.child(j)
                for k in range(layer.childCount()):
                    svc_item = layer.child(k)
                    for m in range(svc_item.childCount()):
                        msg_item = svc_item.child(m)
                        for pidx in range(msg_item.childCount()):
                            p_item = msg_item.child(pidx)
                            if p_item.flags() & Qt.ItemFlag.ItemIsUserCheckable:
                                total += 1
                                if p_item.checkState(0) == Qt.CheckState.Checked:
                                    selected += 1
        self.lbl_selected.setText(f"{selected}/{total} selected")

    def tree_selected(self) -> None:
        sel = self.tree.selectedItems()
        if not sel: return
        item = sel[0]
        payload = item.data(0, Qt.ItemDataRole.UserRole)
        if isinstance(payload, OdxParam):
            self.show_param_details(payload)
        else:
            self._clear_form(self.details)

    def tree_item_changed(self, item: QTreeWidgetItem, col: int) -> None:
        if self._suppress_item_changed: return
        try:
            self._suppress_item_changed = True
            state = item.checkState(0)
            self._set_descendant_checkstate(item, state)
            self._check_ancestors(item)
            self._refresh_ancestor_state(item.parent())
        finally:
            self._suppress_item_changed = False
        self.update_selection_label()

    def _check_ancestors(self, item: QTreeWidgetItem) -> None:
        parent = item.parent()
        while parent is not None:
            if parent.flags() & Qt.ItemFlag.ItemIsUserCheckable:
                if parent.checkState(0) != Qt.CheckState.Checked:
                    parent.setCheckState(0, Qt.CheckState.Checked)
            parent = parent.parent()

    def _set_descendant_checkstate(self, item: QTreeWidgetItem, state: Qt.CheckState) -> None:
        for i in range(item.childCount()):
            ch = item.child(i)
            if ch.flags() & Qt.ItemFlag.ItemIsUserCheckable:
                ch.setCheckState(0, state)
            self._set_descendant_checkstate(ch, state)

    def _refresh_ancestor_state(self, item: Optional[QTreeWidgetItem]) -> None:
        while item is not None:
            if item.flags() & Qt.ItemFlag.ItemIsUserCheckable:
                any_checked = False
                for i in range(item.childCount()):
                    ch = item.child(i)
                    if (ch.flags() & Qt.ItemFlag.ItemIsUserCheckable) and ch.checkState(0) == Qt.CheckState.Checked:
                        any_checked = True; break
                item.setCheckState(0, Qt.CheckState.Checked if any_checked else Qt.CheckState.Unchecked)
            item = item.parent()

    def _clear_form(self, form: QFormLayout) -> None:
        while form.rowCount() > 0:
            form.removeRow(0)

    def _add_detail(self, key: str, value: str) -> None:
        key_lbl = QLabel(key); key_lbl.setProperty("role", "key")
        val_lbl = QLabel(value if value else ""); val_lbl.setWordWrap(True)
        val_lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.details.addRow(key_lbl, val_lbl)

    def show_param_details(self, p: OdxParam) -> None:
        self._clear_form(self.details)
        header = QLabel(f"PARAMETER - {getattr(p, 'parentType', '') or ''}"); self.details.addRow(header, QLabel(""))
        self._add_detail("Short Name", getattr(p, "shortName", "") or "")
        self._add_detail("Long Name", getattr(p, "longName", "") or "")
        self._add_detail("Description", getattr(p, "description", "") or "")
        self._add_detail("Semantic", getattr(p, "semantic", "") or "")
        self._add_detail("Service", getattr(p, "serviceShortName", "") or "")
        self._add_detail("Layer", getattr(p, "layerName", "") or "")
        self._add_detail("Byte Position", str(getattr(p, "bytePosition", "") or ""))
        self._add_detail("Bit Position", str(getattr(p, "bitPosition", "") or ""))
        self._add_detail("Bit Length", str(getattr(p, "bitLength", "") or ""))
        self._add_detail("Base Data Type", getattr(p, "baseDataType", "") or "")
        self._add_detail("Physical Base Type", getattr(p, "physicalBaseType", "") or "")
        self._add_detail("Coded Const", getattr(p, "codedConstValue", "") or "")
        self._add_detail("Phys Const", getattr(p, "physConstValue", "") or "")
        if getattr(p, 'displayValue', None):
            self._add_detail("Value", getattr(p, 'displayValue'))

    def copy_current_did(self) -> None:
        sel = self.tree.selectedItems()
        if not sel:
            self.sb.showMessage("No selection"); return
        item = sel[0]
        payload = item.data(0, Qt.ItemDataRole.UserRole)
        did_val = None
        if isinstance(payload, OdxService):
            did_val = getattr(payload, 'didNormalized', None)
        if not did_val:
            self.sb.showMessage("No DID available from model"); return
        QGuiApplication.clipboard().setText(str(did_val))
        self.sb.showMessage("DID copied to clipboard")

# ----------------------------- Main -----------------------------
def main() -> None:
    app = QApplication(sys.argv)
    w = MainWindow(); w.show(); sys.exit(app.exec())

if __name__ == "__main__":
    main()
